<p align="center">
  <img width=20% height=auto src="https://github.com/AndFang/LeetBoard/blob/main/assets/logo.png" alt="LeetRom icon"/>
</p>

<h3 align="center">LeetBoard</h3>
<p align="center">
  Friends for LeetCode.
</p>

# Features
- Follow different LeetCode profiles!
- Badge that displays your activity LeetCode activity status

# Installation
Chrome extension coming soon!
Developer: View []() for instructions on how to install the extension locally.
  
# Future Updates
- Friend other users
  - Display status of friend
  - Code with friend on same problem
  - View activity of friends  
- User friend request
- Window inside LeetCode problem that displays friend status for current problem
- Leave message for current question
- Activity board of friends
- Order users by variety of fields
